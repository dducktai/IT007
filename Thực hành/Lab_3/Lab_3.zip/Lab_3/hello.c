/*######################################
# University of Information Technology #
# IT007 Operating System
#
# <Your name>, <your Student ID> #
# File: hello.c
#
######################################*/
#include <stdio.h>
#include "hello.h"

void hello(){
    printf("Hello, I am Lai Quan Thien,\n");
    printf("Welcome to IT007!\n");
}
