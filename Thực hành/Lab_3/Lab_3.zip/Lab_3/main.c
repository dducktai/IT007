/*######################################
# University of Information Technology #
# IT007 Operating System
#
# <Your name>, <your Student ID> #
# File: main.c
#
######################################*/

#include "hello.h"
int main()
{
    hello();
    return 0;
}