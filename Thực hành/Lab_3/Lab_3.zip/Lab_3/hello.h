/*######################################
# University of Information Technology #
# IT007 Operating System
#
# <Your name>, <your Student ID> #
# File: hello.h
#
######################################*/
#ifndef __HELLO_H
#define __HELLO_H
void hello();
#endif